package com.voxelcraft

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputAdapter
import com.badlogic.gdx.InputMultiplexer
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import kotlin.math.cos
import kotlin.math.sin

class VoxelGame : ApplicationAdapter() {
    lateinit var world: World
    lateinit var player: Player
    lateinit var cam: PerspectiveCamera
    lateinit var cam3p: Camera3P
    lateinit var controls: TouchControls
    lateinit var shape: ShapeRenderer
    lateinit var hotbar: Hotbar
    lateinit var inventory: Inventory
    lateinit var em: EntityManager
    lateinit var dayNight: DayNight
    lateinit var sky: Sky

    val projView = Matrix4()
    var reachHit: Raycast.Hit? = null
    private var fpsCounter = 0
    private var fpsTimer = 0f
    private var fps = 0
    private var started = false

    override fun create() {
        TextureAtlas.build()
        world = World(System.currentTimeMillis())
        player = Player(world, Vector3(8f, 40f, 8f))
        cam = PerspectiveCamera(70f,
            Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat())
        cam.near = 0.1f; cam.far = 300f
        cam3p = Camera3P(cam)
        controls = TouchControls()
        shape = ShapeRenderer()
        hotbar = Hotbar()
        inventory = Inventory()
        em = EntityManager(world)
        dayNight = DayNight(180f)
        sky = Sky(dayNight) { player.pos }

        em.onKill = { e ->
            when (e.kind) {
                EKind.ZOMBIE -> if (Math.random() < 0.4)
                    player.armor = (player.armor + 20f).coerceAtMost(100f)
                else -> player.hunger = (player.hunger + 15f).coerceAtMost(100f)
            }
        }

        val multiplex = InputMultiplexer(
            object : InputAdapter() {
                override fun touchDown(sx: Int, sy: Int, p: Int, b: Int): Boolean {
                    if (!started) { started = true; return true }
                    val x = sx.toFloat()
                    val y = Gdx.graphics.height - sy.toFloat()
                    if (inventory.open) {
                        if (inventory.hitClose(x, y)) {
                            inventory.open = false; return true
                        }
                        val blk = inventory.hitBlock(x, y)
                        if (blk != null) {
                            hotbar.slots[hotbar.selected] = blk
                            inventory.open = false
                            return true
                        }
                        return true
                    }
                    val slot = hotbar.pick(x, y,
                        Gdx.graphics.width.toFloat(),
                        Gdx.graphics.height.toFloat())
                    if (slot >= 0) { hotbar.selected = slot; return true }
                    return false
                }
            },
            controls
        )
        Gdx.input.inputProcessor = multiplex

        inventory.layout(Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat())
        controls.resize(Gdx.graphics.width, Gdx.graphics.height)
    }

    override fun resize(w: Int, h: Int) {
        cam.viewportWidth = w.toFloat()
        cam.viewportHeight = h.toFloat()
        cam.update()
        controls.resize(w, h)
        inventory.layout(w.toFloat(), h.toFloat())
    }

    override fun render() {
        val dt = Gdx.graphics.deltaTime.coerceAtMost(0.05f)
        val sw = Gdx.graphics.width.toFloat()
        val sh = Gdx.graphics.height.toFloat()

        fpsCounter++; fpsTimer += dt
        if (fpsTimer >= 0.5f) {
            fps = (fpsCounter / fpsTimer).toInt()
            fpsCounter = 0; fpsTimer = 0f
        }

        if (started) {
            handleInput()
            player.update(dt, controls.moveX, controls.moveZ, controls.btnJump.pressed)
            em.update(dt, player, dayNight.isNight)
        }

        dayNight.update(dt)
        world.stream(player.pos, 5)
        cam3p.update(player)
        projView.set(cam.combined)

        val sc = dayNight.skyColor
        Gdx.gl.glClearColor(sc[0], sc[1], sc[2], 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)

        sky.render(shape, cam.combined)

        val shader = ChunkMesher.shader
        shader.begin()
        shader.setUniformMatrix("u_projView", projView)
        shader.setUniformf("u_daylight", dayNight.daylight)
        TextureAtlas.texture.bind(0)
        shader.setUniformi("u_tex", 0)
        for (c in world.chunks.values) c.mesh?.render(shader, GL20.GL_TRIANGLES)
        shader.end()

        em.render(shape, cam.combined)

        shape.projectionMatrix.setToOrtho2D(0f, 0f, sw, sh)
        if (started) {
            Hud.draw(shape, player, sw, sh)
            hotbar.render(shape, sw, sh)
            controls.render(shape)
            inventory.render(shape, sw, sh)
            Hud.drawText(player, sw, sh, fps)
            drawReachHighlight()
        } else {
            shape.begin(ShapeRenderer.ShapeType.Filled)
            shape.color.set(0.06f, 0.09f, 0.14f, 0.9f)
            shape.rect(0f, 0f, sw, sh)
            shape.end()
            TextRender.begin()
            TextRender.text("VOXELCRAFT", sw / 2f - 100f, sh / 2f + 40f, 0.4f, 0.9f, 0.6f)
            TextRender.text("Tap to start", sw / 2f - 70f, sh / 2f - 20f)
            TextRender.end()
        }
    }

    private fun handleInput() {
        if (inventory.open) return
        val (dy, dp) = controls.consumeLook()
        player.yaw += dy
        player.pitch = (player.pitch - dp).coerceIn(-1.4f, 1.4f)
        if (controls.consumePress(controls.btnFly)) player.flying = !player.flying
        if (controls.consumePress(controls.btnInv)) inventory.open = !inventory.open

        val origin = Vector3(player.pos.x, player.pos.y + 1.6f, player.pos.z)
        val dir = Vector3(
            -sin(player.yaw) * cos(player.pitch),
            -sin(player.pitch),
            -cos(player.yaw) * cos(player.pitch)
        ).nor()
        reachHit = Raycast.cast(world, origin, dir, 6f)

        if (controls.consumePress(controls.btnAtk)) {
            val e = em.hitAlongRay(origin, dir, 4f)
            if (e != null) em.damage(e, 9f)
        }
        if (controls.consumePress(controls.btnBreak)) {
            reachHit?.let { world.setBlock(it.x, it.y, it.z, Block.AIR) }
        }
        if (controls.consumePress(controls.btnPlace)) {
            reachHit?.let { h ->
                val px = h.x + h.nx
                val py = h.y + h.ny
                val pz = h.z + h.nz
                val cx = player.pos.x.toInt()
                val cy = player.pos.y.toInt()
                val cz = player.pos.z.toInt()
                if (!(px == cx && (py == cy || py == cy + 1) && pz == cz))
                    world.setBlock(px, py, pz, hotbar.selectedBlock())
            }
        }
    }

    private fun drawReachHighlight() {
        reachHit?.let { h ->
            shape.begin(ShapeRenderer.ShapeType.Line)
            shape.color.set(1f, 1f, 1f, 0.9f)
            shape.projectionMatrix.set(cam.combined)
            val x = h.x.toFloat(); val y = h.y.toFloat(); val z = h.z.toFloat()
            val s = 1.002f
            shape.line(x, y, z, x + s, y, z)
            shape.line(x + s, y, z, x + s, y, z + s)
            shape.line(x + s, y, z + s, x, y, z + s)
            shape.line(x, y, z + s, x, y, z)
            shape.line(x, y + s, z, x + s, y + s, z)
            shape.line(x + s, y + s, z, x + s, y + s, z + s)
            shape.line(x + s, y + s, z + s, x, y + s, z + s)
            shape.line(x, y + s, z + s, x, y + s, z)
            shape.line(x, y, z, x, y + s, z)
            shape.line(x + s, y, z, x + s, y + s, z)
            shape.line(x + s, y, z + s, x + s, y + s, z + s)
            shape.line(x, y, z + s, x, y + s, z + s)
            shape.end()
            shape.projectionMatrix.setToOrtho2D(0f, 0f,
                Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat())
        }
    }

    override fun dispose() {
        world.chunks.values.forEach { it.mesh?.dispose() }
        shape.dispose()
        ChunkMesher.shader.dispose()
        TextureAtlas.texture.dispose()
        TextRender.dispose()
    }
}
