package com.voxelcraft

import com.badlogic.gdx.graphics.Mesh
import com.badlogic.gdx.math.Vector3
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor

enum class Block(
    val id: Byte,
    val r: Float, val g: Float, val b: Float,
    val topTex: Int, val sideTex: Int, val botTex: Int,
    val solid: Boolean = true,
    val transparent: Boolean = false
) {
    AIR   (0, 0f,0f,0f,        -1,-1,-1, false, true),
    GRASS (1, 0.34f,0.62f,0.22f, 0, 1, 2),
    DIRT  (2, 0.45f,0.30f,0.18f, 2, 2, 2),
    STONE (3, 0.55f,0.55f,0.58f, 3, 3, 3),
    SAND  (4, 0.90f,0.85f,0.55f, 4, 4, 4),
    WATER (5, 0.20f,0.45f,0.90f, 5, 5, 5, false, true),
    WOOD  (6, 0.40f,0.25f,0.12f, 6, 6, 6),
    LEAVES(7, 0.15f,0.55f,0.20f, 7, 7, 7, true, true),
    GOLD_APPLE(8, 1f,0.85f,0.20f, 8, 8, 8),
    LAVA  (9, 1f,0.35f,0.05f,   9, 9, 9, false, true),
    TORCH (10, 1f,0.70f,0.20f, 10,10,10, false, true),
    COAL  (11, 0.20f,0.20f,0.22f,11,11,11),
    IRON  (12, 0.85f,0.75f,0.55f,12,12,12),
    DIAMOND(13,0.40f,0.95f,1.00f,13,13,13),
    PLANK (14, 0.65f,0.45f,0.25f,14,14,14),
    BRICK (15, 0.70f,0.30f,0.20f,15,15,15);

    fun texForFace(face: Int): Int = when (face) {
        0 -> topTex; 1 -> botTex; else -> sideTex
    }
    companion object {
        fun fromId(id: Byte): Block = entries.firstOrNull { it.id == id } ?: AIR
        val placeable: List<Block>
            get() = entries.filter { it != AIR && it != WATER && it != LAVA }
    }
}

class Chunk(val cx: Int, val cz: Int) {
    val blocks = ByteArray(SIZE * HEIGHT * SIZE)
    var mesh: Mesh? = null
    @Volatile var dirty = true
    fun idx(x: Int, y: Int, z: Int) = (y * SIZE + z) * SIZE + x
    fun get(x: Int, y: Int, z: Int): Byte {
        if (x < 0 || x >= SIZE || y < 0 || y >= HEIGHT || z < 0 || z >= SIZE) return 0
        return blocks[idx(x, y, z)]
    }
    fun set(x: Int, y: Int, z: Int, id: Byte) {
        if (x < 0 || x >= SIZE || y < 0 || y >= HEIGHT || z < 0 || z >= SIZE) return
        blocks[idx(x, y, z)] = id
    }
    companion object { const val SIZE = 16; const val HEIGHT = 48 }
}

class TerrainGen(val seed: Long) {
    private fun hash(x: Int, z: Int, salt: Int): Float {
        var h = x * 374761393 + z * 668265263 + (seed xor salt.toLong()).toInt()
        h = (h xor (h shr 13)) * 1274126177
        return (h and 0x7fffffff).toFloat() / 0x7fffffff.toFloat()
    }
    private fun smooth(x: Int, z: Int, scale: Int, salt: Int): Float {
        val fx = x.toFloat() / scale; val fz = z.toFloat() / scale
        val x0 = floor(fx).toInt(); val z0 = floor(fz).toInt()
        val tx = fx - x0; val tz = fz - z0
        val a = hash(x0, z0, salt);     val b = hash(x0 + 1, z0, salt)
        val c = hash(x0, z0 + 1, salt); val d = hash(x0 + 1, z0 + 1, salt)
        val ux = tx * tx * (3 - 2 * tx); val uz = tz * tz * (3 - 2 * tz)
        return (a * (1 - ux) + b * ux) * (1 - uz) + (c * (1 - ux) + d * ux) * uz
    }
    fun heightAt(wx: Int, wz: Int): Int {
        var h = 0f
        h += smooth(wx, wz, 64, 1) * 10f
        h += smooth(wx, wz, 32, 2) * 5f
        h += smooth(wx, wz, 16, 3) * 2f
        return (18 + h).toInt().coerceIn(4, Chunk.HEIGHT - 8)
    }
    fun generate(chunk: Chunk) {
        val ox = chunk.cx * Chunk.SIZE; val oz = chunk.cz * Chunk.SIZE
        for (x in 0 until Chunk.SIZE) for (z in 0 until Chunk.SIZE) {
            val wx = ox + x; val wz = oz + z
            val h = heightAt(wx, wz)
            for (y in 0..h) {
                val id: Byte = when {
                    y == h && h >= 15 -> Block.GRASS.id
                    y == h && h < 15  -> Block.SAND.id
                    y > h - 4         -> Block.DIRT.id
                    else              -> Block.STONE.id
                }
                chunk.set(x, y, z, id)
            }
            if (h < 13) for (y in h + 1..13) chunk.set(x, y, z, Block.WATER.id)
            if (hash(wx, wz, 50) > 0.96f) for (y in 4..9) chunk.set(x, y, z, Block.COAL.id)
            if (hash(wx, wz, 60) > 0.985f) for (y in 4..8) chunk.set(x, y, z, Block.IRON.id)
            if (hash(wx, wz, 70) > 0.995f) for (y in 3..6) chunk.set(x, y, z, Block.DIAMOND.id)
            for (y in 5..25) if (hash(wx * 7 + y * 11, wz * 13 + y * 3, 80) > 0.92f)
                chunk.set(x, y, z, Block.AIR.id)
            if (h > 15 && hash(wx, wz, 99) > 0.985f) tree(chunk, x, h + 1, z)
        }
    }
    private fun tree(c: Chunk, x: Int, y: Int, z: Int) {
        for (i in 0 until 5) if (y + i < Chunk.HEIGHT) c.set(x, y + i, z, Block.WOOD.id)
        for (dx in -2..2) for (dz in -2..2) for (dy in 3..5) {
            if (dx * dx + dz * dz > 4) continue
            val nx = x + dx; val nz = z + dz; val ny = y + dy
            if (nx in 0 until 16 && nz in 0 until 16 && ny < Chunk.HEIGHT &&
                c.get(nx, ny, nz) == Block.AIR.id)
                c.set(nx, ny, nz, Block.LEAVES.id)
        }
    }
}

class World(val seed: Long) {
    val chunks = ConcurrentHashMap<Long, Chunk>()
    val gen = TerrainGen(seed)
    val edits = HashMap<String, Byte>()

    private fun key(cx: Int, cz: Int): Long =
        (cx.toLong() shl 32) or (cz.toLong() and 0xffffffffL)

    fun getChunk(cx: Int, cz: Int): Chunk =
        chunks.computeIfAbsent(key(cx, cz)) {
            val c = Chunk(cx, cz); gen.generate(c); c
        }

    fun getBlock(x: Int, y: Int, z: Int): Block {
        if (y < 0 || y >= Chunk.HEIGHT) return Block.AIR
        return Block.fromId(getChunk(x shr 4, z shr 4).get(x and 15, y, z and 15))
    }

    fun setBlock(x: Int, y: Int, z: Int, b: Block) {
        if (y < 0 || y >= Chunk.HEIGHT) return
        val cx = x shr 4; val cz = z shr 4
        getChunk(cx, cz).set(x and 15, y, z and 15, b.id)
        getChunk(cx, cz).dirty = true
        if ((x and 15) == 0)  getChunk(cx - 1, cz).dirty = true
        if ((x and 15) == 15) getChunk(cx + 1, cz).dirty = true
        if ((z and 15) == 0)  getChunk(cx, cz - 1).dirty = true
        if ((z and 15) == 15) getChunk(cx, cz + 1).dirty = true
        edits["$x,$y,$z"] = b.id
    }

    fun buildMesh(chunk: Chunk) {
        chunk.mesh?.dispose()
        chunk.mesh = ChunkMesher.build(this, chunk)
        chunk.dirty = false
    }

    fun stream(pos: Vector3, radius: Int) {
        val pcx = (pos.x / 16f).toInt(); val pcz = (pos.z / 16f).toInt()
        val toBuild = ArrayList<Long>()
        for (dx in -radius..radius) for (dz in -radius..radius) {
            val c = getChunk(pcx + dx, pcz + dz)
            if (c.mesh == null || c.dirty) toBuild.add(key(pcx + dx, pcz + dz))
        }
        toBuild.sortBy { k ->
            val cx = (k shr 32).toInt(); val cz = k.toInt()
            (cx - pcx) * (cx - pcx) + (cz - pcz) * (cz - pcz)
        }
        var budget = 2
        for (k in toBuild) {
            if (budget-- <= 0) break
            chunks[k]?.let { buildMesh(it) }
        }
        chunks.entries.removeIf { (k, c) ->
            val cx = (k shr 32).toInt(); val cz = k.toInt()
            val d = (cx - pcx) * (cx - pcx) + (cz - pcz) * (cz - pcz)
            if (d > (radius + 3) * (radius + 3)) { c.mesh?.dispose(); true } else false
        }
    }
}
