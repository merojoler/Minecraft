package com.voxelcraft

import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import kotlin.math.cos
import kotlin.math.sin

class DayNight(val cycleSeconds: Float = 180f) {
    var time = cycleSeconds * 0.25f
    fun update(dt: Float) { time = (time + dt) % cycleSeconds }
    val daylight: Float get() {
        val t = time / cycleSeconds
        val s = kotlin.math.sin((t - 0.25f) * Math.PI.toFloat() * 2f)
        return (s * 0.5f + 0.5f).coerceIn(0f, 1f)
    }
    val isNight: Boolean get() = daylight < 0.35f
    val skyColor: FloatArray get() {
        val d = daylight
        val night = floatArrayOf(0.03f, 0.05f, 0.15f)
        val sunset = floatArrayOf(0.85f, 0.45f, 0.25f)
        val day = floatArrayOf(0.55f, 0.75f, 0.95f)
        return when {
            d < 0.20f -> mix(night, sunset, d / 0.20f)
            d < 0.45f -> mix(sunset, day, (d - 0.20f) / 0.25f)
            else -> day
        }
    }
    private fun mix(a: FloatArray, b: FloatArray, t: Float) =
        floatArrayOf(a[0]*(1-t)+b[0]*t, a[1]*(1-t)+b[1]*t, a[2]*(1-t)+b[2]*t)
}

class Sky(private val cycle: DayNight, private val camPos: () -> Vector3) {
    fun render(shape: ShapeRenderer, proj: Matrix4) {
        val t = cycle.time / cycle.cycleSeconds
        val ang = t * Math.PI.toFloat() * 2f
        val c = camPos()
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.projectionMatrix.set(proj)
        if (cycle.daylight > 0.15f) {
            shape.setColor(1f, 0.95f, 0.4f, 1f)
            shape.sphere(c.x + cos(ang) * 200f, c.y + sin(ang) * 200f, c.z + 30f, 10f, 8, 8)
        }
        if (cycle.daylight < 0.85f) {
            shape.setColor(0.85f, 0.85f, 0.95f, 0.9f)
            shape.sphere(c.x - cos(ang) * 200f, c.y - sin(ang) * 200f, c.z + 30f, 7f, 8, 8)
        }
        shape.end()
    }
}
