package com.voxelcraft

import android.os.Bundle
import android.view.WindowManager
import com.badlogic.gdx.backends.android.AndroidApplication
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration

class AndroidLauncher : AndroidApplication() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val cfg = AndroidApplicationConfiguration().apply {
            useGL30 = false
            useAccelerometer = false
            useCompass = false
            useWakelock = true
            numSamples = 0
        }
        initialize(VoxelGame(), cfg)
    }
}
