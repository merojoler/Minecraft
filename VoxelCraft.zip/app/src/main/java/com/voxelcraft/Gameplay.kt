package com.voxelcraft

import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

class Player(val world: World, spawn: Vector3) {
    val pos = Vector3(spawn)
    val vel = Vector3()
    var yaw = 0f
    var pitch = 0.3f
    var hp = 100f
    var armor = 0f
    var hunger = 100f
    var flying = false
    var onGround = false

    fun update(dt: Float, moveX: Float, moveZ: Float, jump: Boolean) {
        val speed = if (flying) 12f else 5f
        val s = sin(yaw); val c = cos(yaw)
        vel.x = (moveX * c - moveZ * s) * speed
        vel.z = (moveX * s + moveZ * c) * speed
        if (flying) vel.y = if (jump) 8f else 0f
        else { vel.y -= 25f * dt; if (jump && onGround) vel.y = 8.5f }
        pos.add(vel.x * dt, vel.y * dt, vel.z * dt)
        val bx = pos.x.toInt(); val bz = pos.z.toInt()
        var gy = pos.y.toInt()
        while (gy > 0 && world.getBlock(bx, gy - 1, bz) == Block.AIR) gy--
        val groundY = gy + 1.8f
        if (pos.y < groundY) { pos.y = groundY; vel.y = 0f; onGround = true }
        else onGround = false
        hunger = (hunger - dt * 0.25f).coerceAtLeast(0f)
        if (hunger <= 0f) hp = (hp - dt * 1.5f).coerceAtLeast(0f)
        if (hunger > 60f && hp < 100f) hp = (hp + dt * 0.6f).coerceAtMost(100f)
    }
}

class Camera3P(val cam: PerspectiveCamera) {
    private val target = Vector3()
    fun update(player: Player) {
        target.set(player.pos.x, player.pos.y + 1.5f, player.pos.z)
        val d = 5.5f
        val dx = -sin(player.yaw) * cos(player.pitch) * d
        val dy = -sin(player.pitch) * d
        val dz = -cos(player.yaw) * cos(player.pitch) * d
        cam.position.set(target.x - dx, target.y - dy + 0.6f, target.z - dz)
        cam.lookAt(target)
        cam.up.set(Vector3.Y)
        cam.update()
    }
}

object Raycast {
    data class Hit(
        val x: Int, val y: Int, val z: Int,
        val nx: Int, val ny: Int, val nz: Int,
        val block: Block)

    fun cast(world: World, origin: Vector3, dir: Vector3, maxDist: Float): Hit? {
        var x = floor(origin.x).toInt()
        var y = floor(origin.y).toInt()
        var z = floor(origin.z).toInt()
        val sx = if (dir.x > 0) 1 else -1
        val sy = if (dir.y > 0) 1 else -1
        val sz = if (dir.z > 0) 1 else -1
        val tdx = if (dir.x != 0f) abs(1f / dir.x) else Float.MAX_VALUE
        val tdy = if (dir.y != 0f) abs(1f / dir.y) else Float.MAX_VALUE
        val tdz = if (dir.z != 0f) abs(1f / dir.z) else Float.MAX_VALUE
        var tmx = if (dir.x != 0f)
            (if (sx > 0) x + 1 - origin.x else origin.x - x) * tdx else Float.MAX_VALUE
        var tmy = if (dir.y != 0f)
            (if (sy > 0) y + 1 - origin.y else origin.y - y) * tdy else Float.MAX_VALUE
        var tmz = if (dir.z != 0f)
            (if (sz > 0) z + 1 - origin.z else origin.z - z) * tdz else Float.MAX_VALUE
        var nx = 0; var ny = 0; var nz = 0; var t = 0f
        while (t <= maxDist) {
            val b = world.getBlock(x, y, z)
            if (b != Block.AIR && b != Block.WATER) return Hit(x, y, z, nx, ny, nz, b)
            when {
                tmx < tmy && tmx < tmz -> { x += sx; t = tmx; tmx += tdx; nx = -sx; ny = 0; nz = 0 }
                tmy < tmz             -> { y += sy; t = tmy; tmy += tdy; nx = 0; ny = -sy; nz = 0 }
                else                  -> { z += sz; t = tmz; tmz += tdz; nx = 0; ny = 0; nz = -sz }
            }
        }
        return null
    }
}

enum class EKind { ZOMBIE, COW, PIG, SHEEP }

class Entity(var pos: Vector3, val kind: EKind) {
    var hp = if (kind == EKind.ZOMBIE) 20f else 10f
    var dead = false
    var attackCd = 0f
    var wander = 0f
    var dx = 0f; var dz = 0f
    var hurtFlash = 0f
    val speed = if (kind == EKind.ZOMBIE) 2.2f else 1.3f
    val color = when (kind) {
        EKind.ZOMBIE -> floatArrayOf(0.25f, 0.65f, 0.30f)
        EKind.COW    -> floatArrayOf(0.92f, 0.92f, 0.92f)
        EKind.PIG    -> floatArrayOf(1.00f, 0.70f, 0.78f)
        EKind.SHEEP  -> floatArrayOf(0.95f, 0.95f, 0.88f)
    }
    fun update(dt: Float, world: World, player: Player) {
        hurtFlash = (hurtFlash - dt).coerceAtLeast(0f)
        if (kind == EKind.ZOMBIE) {
            val dx0 = player.pos.x - pos.x; val dz0 = player.pos.z - pos.z
            val d = Math.hypot(dx0.toDouble(), dz0.toDouble()).toFloat()
            if (d in 0.8f..22f) {
                pos.x += (dx0 / d) * speed * dt
                pos.z += (dz0 / d) * speed * dt
            }
            attackCd -= dt
            if (d < 1.6f && attackCd <= 0f) {
                player.hp = (player.hp - 6f).coerceAtLeast(0f)
                attackCd = 1.2f
            }
        } else {
            wander -= dt
            if (wander <= 0f) {
                wander = 2f + (Math.random() * 3).toFloat()
                dx = ((Math.random() - 0.5) * 0.6).toFloat()
                dz = ((Math.random() - 0.5) * 0.6).toFloat()
            }
            val d = pos.dst(player.pos)
            if (d < 4f) {
                val ax = pos.x - player.pos.x; val az = pos.z - player.pos.z
                val len = Math.hypot(ax.toDouble(), az.toDouble()).toFloat().coerceAtLeast(0.01f)
                pos.x += (ax / len) * speed * 1.5f * dt
                pos.z += (az / len) * speed * 1.5f * dt
            } else {
                pos.x += dx * speed * dt
                pos.z += dz * speed * dt
            }
        }
        pos.y -= 12f * dt
        var gy = pos.y.toInt()
        while (gy > 0 && world.getBlock(pos.x.toInt(), gy - 1, pos.z.toInt()) == Block.AIR) gy--
        pos.y = gy + 1.0f
    }
}

class EntityManager(private val world: World) {
    val entities = ArrayList<Entity>()
    private var spawnTimer = 0f
    var onKill: ((Entity) -> Unit)? = null

    fun update(dt: Float, player: Player, isNight: Boolean) {
        spawnTimer += dt
        if (spawnTimer > 2.5f && entities.size < 25) {
            spawnTimer = 0f; spawnAround(player, isNight)
        }
        val it = entities.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.dead) { it.remove(); continue }
            if (e.pos.dst(player.pos) > 80f) { it.remove(); continue }
            e.update(dt, world, player)
        }
    }

    private fun spawnAround(player: Player, isNight: Boolean) {
        val ang = Math.random() * Math.PI * 2
        val dist = 18f + Math.random().toFloat() * 20f
        val x = player.pos.x + Math.cos(ang).toFloat() * dist
        val z = player.pos.z + Math.sin(ang).toFloat() * dist
        var y = Chunk.HEIGHT - 1
        while (y > 0 && world.getBlock(x.toInt(), y, z.toInt()) == Block.AIR) y--
        val pos = Vector3(x, y + 1f, z)
        val r = Math.random()
        val kind = when {
            r < (if (isNight) 0.75 else 0.30) -> EKind.ZOMBIE
            r < 0.55 -> EKind.COW
            r < 0.80 -> EKind.PIG
            else -> EKind.SHEEP
        }
        entities.add(Entity(pos, kind))
    }

    fun hitAlongRay(origin: Vector3, dir: Vector3, maxDist: Float): Entity? {
        var best: Entity? = null; var bestT = maxDist
        for (e in entities) {
            val to = Vector3(e.pos).sub(origin)
            val t = to.dot(dir)
            if (t < 0 || t > bestT) continue
            val c = Vector3(dir).scl(t).add(origin)
            if (c.dst(Vector3(e.pos.x, e.pos.y + 0.9f, e.pos.z)) < 1.0f) {
                best = e; bestT = t
            }
        }
        return best
    }

    fun damage(e: Entity, dmg: Float) {
        e.hp -= dmg
        e.hurtFlash = 0.25f
        if (e.hp <= 0f) { e.dead = true; onKill?.invoke(e) }
    }

    fun render(shape: ShapeRenderer, proj: Matrix4) {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.projectionMatrix.set(proj)
        for (e in entities) {
            if (e.hurtFlash > 0f) shape.setColor(1f, 0.3f, 0.3f, 1f)
            else shape.setColor(e.color[0], e.color[1], e.color[2], 1f)
            shape.box(e.pos.x - 0.35f, e.pos.y, e.pos.z - 0.35f, 0.7f, 1.8f, 0.7f)
            shape.setColor(0.1f, 0.1f, 0.1f, 1f)
            shape.rect(e.pos.x - 0.5f, e.pos.y + 2.0f, 1f, 0.08f)
            shape.setColor(1f, 0.2f, 0.2f, 1f)
            shape.rect(e.pos.x - 0.5f, e.pos.y + 2.0f, (e.hp / 20f).coerceIn(0f, 1f), 0.08f)
        }
        shape.end()
    }
}
