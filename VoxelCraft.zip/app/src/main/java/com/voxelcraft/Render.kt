package com.voxelcraft

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Mesh
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttribute
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.glutils.ShaderProgram

object TextureAtlas {
    const val TILE = 16
    const val COLS = 4
    lateinit var texture: Texture

    fun build() {
        val pix = Pixmap(COLS * TILE, COLS * TILE, Pixmap.Format.RGBA8888)
        pix.setColor(Color.BLACK); pix.fill()
        painter(pix, 0) { x, y -> noise(0.35f, 0.70f, 0.28f, x, y, 6) }
        painter(pix, 1) { x, y -> if (y < 4) noise(0.35f, 0.70f, 0.28f, x, y, 4) else noise(0.45f, 0.30f, 0.18f, x, y, 6) }
        painter(pix, 2) { x, y -> noise(0.45f, 0.30f, 0.18f, x, y, 6) }
        painter(pix, 3) { x, y -> noise(0.55f, 0.55f, 0.58f, x, y, 8) }
        painter(pix, 4) { x, y -> noise(0.90f, 0.85f, 0.55f, x, y, 4) }
        painter(pix, 5) { x, y -> noise(0.20f, 0.45f, 0.90f, x, y, 8) }
        painter(pix, 6) { x, y ->
            val r = (x - 8) * (x - 8) + (y - 8) * (y - 8)
            val n = (r % 12) / 60f
            Color(0.40f + n, 0.25f + n, 0.12f + n, 1f)
        }
        painter(pix, 7) { x, y ->
            if ((x * 37 + y * 91) % 100 < 30) Color(0f, 0f, 0f, 0f)
            else noise(0.15f, 0.55f, 0.20f, x, y, 15)
        }
        painter(pix, 8) { x, y ->
            val d = Math.hypot((x - 8).toDouble(), (y - 8).toDouble())
            if (d < 6) Color(1f, 0.85f, 0.2f, 1f) else Color(0f, 0f, 0f, 0f)
        }
        painter(pix, 9) { x, y ->
            val n = (Math.sin((x + y) * 0.6) * 0.1 + 0.15).toFloat()
            Color(1f, 0.30f + n, 0.05f, 1f)
        }
        painter(pix, 10) { x, y ->
            val d = Math.hypot((x - 8).toDouble(), (y - 4).toDouble())
            when {
                d < 5 -> Color(1f, 0.7f, 0.1f, 1f)
                x in 6..10 && y > 8 -> Color(0.4f, 0.25f, 0.12f, 1f)
                else -> Color(0f, 0f, 0f, 0f)
            }
        }
        painter(pix, 11) { x, y -> if ((x * 13 + y * 29) % 40 < 3) Color(0.05f, 0.05f, 0.05f, 1f) else noise(0.55f, 0.55f, 0.58f, x, y, 8) }
        painter(pix, 12) { x, y -> if ((x * 11 + y * 17) % 45 < 4) Color(0.85f, 0.75f, 0.55f, 1f) else noise(0.55f, 0.55f, 0.58f, x, y, 8) }
        painter(pix, 13) { x, y -> if ((x * 19 + y * 23) % 50 < 3) Color(0.4f, 0.95f, 1f, 1f) else noise(0.55f, 0.55f, 0.58f, x, y, 8) }
        painter(pix, 14) { x, y -> val n = ((y / 8) % 2) * 0.05f; Color(0.65f + n, 0.45f + n, 0.25f + n, 1f) }
        painter(pix, 15) { x, y ->
            val row = y / 4
            val bx = if (row % 2 == 0) x else (x + 4) % TILE
            if ((y % 4 == 0) || (bx % 8 == 0)) Color(0.7f, 0.7f, 0.7f, 1f)
            else Color(0.7f, 0.3f, 0.2f, 1f)
        }
        texture = Texture(pix)
        texture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest)
        pix.dispose()
    }
    private fun noise(r: Float, g: Float, b: Float, x: Int, y: Int, div: Int): Color {
        val n = ((x * 31 + y * 17) % div) / (div * 4f)
        return Color(r + n, g + n, b + n, 1f)
    }
    private inline fun painter(pix: Pixmap, idx: Int, f: (Int, Int) -> Color) {
        val ox = (idx % COLS) * TILE; val oy = (idx / COLS) * TILE
        for (y in 0 until TILE) for (x in 0 until TILE) {
            pix.setColor(f(x, y)); pix.drawPixel(ox + x, oy + y)
        }
    }
}

object ChunkMesher {
    private data class Face(
        val dx: Int, val dy: Int, val dz: Int,
        val verts: FloatArray, val shade: Float, val faceId: Int)

    private val FACES = arrayOf(
        Face(0, 1, 0, floatArrayOf(
            0f,1f,0f, 0f,0f,  0f,1f,1f, 0f,1f,  1f,1f,1f, 1f,1f,  1f,1f,0f, 1f,0f
        ), 1.00f, 0),
        Face(0,-1, 0, floatArrayOf(
            0f,0f,0f, 0f,0f,  1f,0f,0f, 1f,0f,  1f,0f,1f, 1f,1f,  0f,0f,1f, 0f,1f
        ), 0.50f, 1),
        Face(1, 0, 0, floatArrayOf(
            1f,0f,1f, 0f,0f,  1f,0f,0f, 0f,1f,  1f,1f,0f, 1f,1f,  1f,1f,1f, 1f,0f
        ), 0.85f, 2),
        Face(-1,0, 0, floatArrayOf(
            0f,0f,0f, 0f,1f,  0f,0f,1f, 1f,1f,  0f,1f,1f, 1f,0f,  0f,1f,0f, 0f,0f
        ), 0.85f, 2),
        Face(0, 0, 1, floatArrayOf(
            0f,0f,1f, 1f,1f,  1f,0f,1f, 0f,1f,  1f,1f,1f, 0f,0f,  0f,1f,1f, 1f,0f
        ), 0.75f, 2),
        Face(0, 0,-1, floatArrayOf(
            1f,0f,0f, 1f,0f,  0f,0f,0f, 0f,0f,  0f,1f,0f, 0f,1f,  1f,1f,0f, 1f,1f
        ), 0.75f, 2)
    )
    private const val ATLAS = 4f
    private val color = Color()

    fun build(world: World, chunk: Chunk): Mesh {
        val verts = ArrayList<Float>(20000)
        val idx = ArrayList<Short>(10000)
        val ox = chunk.cx * Chunk.SIZE; val oz = chunk.cz * Chunk.SIZE

        for (y in 0 until Chunk.HEIGHT)
            for (z in 0 until Chunk.SIZE)
                for (x in 0 until Chunk.SIZE) {
                    val id = chunk.get(x, y, z)
                    if (id == 0.toByte()) continue
                    val b = Block.fromId(id)
                    val wx = ox + x; val wz = oz + z
                    for (f in FACES) {
                        val nb = world.getBlock(wx + f.dx, y + f.dy, wz + f.dz)
                        if (nb != Block.AIR && nb != Block.WATER && nb != Block.LAVA) continue
                        if (b == Block.WATER && nb == Block.WATER) continue
                        if (b == Block.LAVA && nb == Block.LAVA) continue

                        val tex = b.texForFace(f.faceId)
                        val u0 = (tex % 4).toFloat() / ATLAS
                        val v0 = (tex / 4).toFloat() / ATLAS
                        val uS = 1f / ATLAS; val vS = 1f / ATLAS
                        color.set(b.r * f.shade, b.g * f.shade, b.b * f.shade,
                            if (b == Block.WATER) 0.75f else 1f)
                        val packed = color.toFloatBits()
                        val base = (verts.size / 6).toShort()
                        for (v in 0 until 4) {
                            verts.add(x + f.verts[v * 5])
                            verts.add(y + f.verts[v * 5 + 1])
                            verts.add(z + f.verts[v * 5 + 2])
                            verts.add(u0 + f.verts[v * 5 + 3] * uS)
                            verts.add(v0 + f.verts[v * 5 + 4] * vS)
                            verts.add(packed)
                        }
                        idx.add(base); idx.add((base + 1).toShort()); idx.add((base + 2).toShort())
                        idx.add(base); idx.add((base + 2).toShort()); idx.add((base + 3).toShort())
                    }
                }

        val mesh = Mesh(false,
            maxOf(verts.size / 6, 1), maxOf(idx.size, 1),
            VertexAttribute(Usage.Position, 3, "a_position"),
            VertexAttribute(Usage.TextureCoordinates, 2, "a_uv"),
            VertexAttribute(Usage.ColorPacked, 4, "a_color"))
        if (verts.isNotEmpty()) {
            mesh.setVertices(verts.toFloatArray())
            mesh.setIndices(idx.toShortArray())
        }
        return mesh
    }

    val shader: ShaderProgram = ShaderProgram(
        """
        attribute vec3 a_position;
        attribute vec2 a_uv;
        attribute vec4 a_color;
        uniform mat4 u_projView;
        uniform float u_daylight;
        varying vec2 v_uv;
        varying vec4 v_color;
        void main(){
            float amb = mix(0.28, 1.0, u_daylight);
            v_color = vec4(a_color.rgb * amb, a_color.a);
            v_uv = a_uv;
            gl_Position = u_projView * vec4(a_position, 1.0);
        }
        """.trimIndent(),
        """
        precision mediump float;
        uniform sampler2D u_tex;
        varying vec2 v_uv;
        varying vec4 v_color;
        void main(){
            vec4 t = texture2D(u_tex, v_uv);
            if (t.a < 0.1) discard;
            gl_FragColor = t * v_color;
        }
        """.trimIndent()
    ).apply { if (!isCompiled) throw RuntimeException("Shader: $log") }
}
