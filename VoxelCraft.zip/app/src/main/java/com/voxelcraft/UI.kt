package com.voxelcraft

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.Vector2
import kotlin.math.hypot

object TextRender {
    val font: BitmapFont = BitmapFont().apply { data.setScale(1.3f); color = Color.WHITE }
    val batch = SpriteBatch()
    fun begin() {
        batch.projectionMatrix.setToOrtho2D(
            0f, 0f,
            Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat())
        batch.begin()
    }
    fun text(s: String, x: Float, y: Float) {
        font.color = Color.WHITE; font.draw(batch, s, x, y)
    }
    fun text(s: String, x: Float, y: Float, r: Float, g: Float, b: Float) {
        font.color = Color(r, g, b, 1f); font.draw(batch, s, x, y)
    }
    fun end() { batch.end() }
    fun dispose() { font.dispose(); batch.dispose() }
}

class TouchControls : InputAdapter() {
    val joyCenter = Vector2(220f, 220f)
    val joyKnob = Vector2(220f, 220f)
    var joyPointer = -1
    var moveX = 0f; var moveZ = 0f
    var lookPointer = -1
    var lastLookX = 0f; var lastLookY = 0f
    var dxYaw = 0f; var dyPitch = 0f

    inner class Btn(var x: Float, var y: Float, var w: Float, var h: Float) {
        var pressed = false
    }
    val btnBreak = Btn(0f,0f,130f,130f)
    val btnPlace = Btn(0f,0f,130f,130f)
    val btnJump  = Btn(0f,0f,110f,110f)
    val btnFly   = Btn(0f,0f,110f,110f)
    val btnInv   = Btn(0f,0f,100f,100f)
    val btnAtk   = Btn(0f,0f,110f,110f)

    private val all get() = listOf(btnBreak, btnPlace, btnJump, btnFly, btnInv, btnAtk)
    private val consumed = HashMap<Btn, Boolean>()
    var sw = 0f; var sh = 0f

    fun resize(w: Int, h: Int) {
        sw = w.toFloat(); sh = h.toFloat()
        joyCenter.set(220f, 220f); joyKnob.set(joyCenter)
        btnBreak.x = sw - 30f - btnBreak.w; btnBreak.y = 130f
        btnPlace.x = btnBreak.x - btnPlace.w - 15f; btnPlace.y = 130f
        btnAtk.x = sw - 30f - btnAtk.w; btnAtk.y = btnBreak.y + btnBreak.h + 20f
        btnJump.x = sw - 30f - btnJump.w; btnJump.y = 30f
        btnFly.x = btnJump.x - btnFly.w - 15f; btnFly.y = 30f
        btnInv.x = sw - 20f - btnInv.w; btnInv.y = sh - 20f - btnInv.h
    }
    private fun inRect(b: Btn, x: Float, y: Float) =
        x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h

    override fun touchDown(sx: Int, sy: Int, p: Int, b: Int): Boolean {
        val x = sx.toFloat(); val y = sh - sy.toFloat()
        for (btn in all) if (inRect(btn, x, y)) { btn.pressed = true; return true }
        if (x < sw * 0.4f && joyPointer == -1) {
            joyPointer = p; joyKnob.set(x, y); return true
        }
        lookPointer = p; lastLookX = x; lastLookY = y; return true
    }
    override fun touchDragged(sx: Int, sy: Int, p: Int): Boolean {
        val x = sx.toFloat(); val y = sh - sy.toFloat()
        if (p == joyPointer) {
            val dx = x - joyCenter.x; val dy = y - joyCenter.y
            val len = hypot(dx, dy); val max = 150f
            val k = if (len > max) max / len else 1f
            joyKnob.set(joyCenter.x + dx * k, joyCenter.y + dy * k)
            moveX = (joyKnob.x - joyCenter.x) / max
            moveZ = -(joyKnob.y - joyCenter.y) / max
        } else if (p == lookPointer) {
            dxYaw += (x - lastLookX) * 0.005f
            dyPitch += (y - lastLookY) * 0.005f
            lastLookX = x; lastLookY = y
        }
        return true
    }
    override fun touchUp(sx: Int, sy: Int, p: Int, b: Int): Boolean {
        if (p == joyPointer) {
            joyPointer = -1; joyKnob.set(joyCenter); moveX = 0f; moveZ = 0f
        }
        if (p == lookPointer) lookPointer = -1
        for (btn in all) if (btn.pressed) btn.pressed = false
        return true
    }
    fun consumeLook(): Pair<Float, Float> {
        val r = dxYaw to dyPitch; dxYaw = 0f; dyPitch = 0f; return r
    }
    fun consumePress(b: Btn): Boolean {
        if (b.pressed && consumed[b] != true) { consumed[b] = true; return true }
        if (!b.pressed) consumed[b] = false
        return false
    }
    fun render(shape: ShapeRenderer) {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.color.set(0.1f, 0.1f, 0.1f, 0.35f)
        shape.circle(joyCenter.x, joyCenter.y, 150f, 32)
        shape.color.set(0.9f, 0.9f, 0.9f, 0.55f)
        shape.circle(joyKnob.x, joyKnob.y, 55f, 24)
        for (btn in all) {
            val col = when (btn) {
                btnBreak -> floatArrayOf(0.55f, 0.15f, 0.15f)
                btnPlace -> floatArrayOf(0.15f, 0.35f, 0.55f)
                btnAtk   -> floatArrayOf(0.55f, 0.35f, 0.10f)
                btnFly   -> floatArrayOf(0.20f, 0.20f, 0.55f)
                else     -> floatArrayOf(0.20f, 0.20f, 0.20f)
            }
            shape.color.set(col[0], col[1], col[2], if (btn.pressed) 0.95f else 0.65f)
            shape.rect(btn.x, btn.y, btn.w, btn.h)
            shape.color.set(1f, 1f, 1f, 0.75f); val t = 4f
            shape.rectLine(btn.x, btn.y, btn.x + btn.w, btn.y, t)
            shape.rectLine(btn.x, btn.y, btn.x, btn.y + btn.h, t)
            shape.rectLine(btn.x + btn.w, btn.y, btn.x + btn.w, btn.y + btn.h, t)
            shape.rectLine(btn.x, btn.y + btn.h, btn.x + btn.w, btn.y + btn.h, t)
        }
        shape.end()
        TextRender.begin()
        TextRender.text("BRK", btnBreak.x + 40f, btnBreak.y + 70f)
        TextRender.text("PUT", btnPlace.x + 40f, btnPlace.y + 70f)
        TextRender.text("ATK", btnAtk.x + 38f, btnAtk.y + 60f)
        TextRender.text("JMP", btnJump.x + 32f, btnJump.y + 60f)
        TextRender.text("FLY", btnFly.x + 32f, btnFly.y + 60f)
        TextRender.text("INV", btnInv.x + 30f, btnInv.y + 55f)
        TextRender.end()
    }
}

class Hotbar(val size: Int = 9) {
    val slots = arrayOf(
        Block.GRASS, Block.DIRT, Block.STONE, Block.SAND,
        Block.WOOD, Block.LEAVES, Block.TORCH, Block.PLANK, Block.BRICK)
    var selected = 0
    fun selectedBlock() = slots[selected]
    fun pick(sx: Float, sy: Float, sw: Float, sh: Float): Int {
        val ss = minOf(sw, 900f) / size
        val totalW = ss * size
        val startX = (sw - totalW) / 2f
        val startY = 20f
        if (sy < startY || sy > startY + ss) return -1
        if (sx < startX || sx > startX + totalW) return -1
        return ((sx - startX) / ss).toInt().coerceIn(0, size - 1)
    }
    fun render(shape: ShapeRenderer, sw: Float, sh: Float) {
        val ss = minOf(sw, 900f) / size
        val totalW = ss * size
        val startX = (sw - totalW) / 2f
        val startY = 20f
        shape.begin(ShapeRenderer.ShapeType.Filled)
        for (i in 0 until size) {
            val x = startX + i * ss
            shape.color.set(0f, 0f, 0f, 0.5f)
            shape.rect(x + 3, startY, ss - 6, ss - 6)
            val b = slots[i]
            shape.color.set(b.r, b.g, b.b, 1f)
            shape.rect(x + 10, startY + 7, ss - 20, ss - 20)
            if (i == selected) {
                shape.color.set(1f, 1f, 1f, 1f)
                shape.rectLine(x + 3, startY, x + ss - 3, startY, 4f)
                shape.rectLine(x + 3, startY, x + 3, startY + ss - 6, 4f)
                shape.rectLine(x + ss - 3, startY, x + ss - 3, startY + ss - 6, 4f)
                shape.rectLine(x + 3, startY + ss - 6, x + ss - 3, startY + ss - 6, 4f)
            }
        }
        shape.end()
    }
}

class Inventory {
    var open = false
    val blocks = Block.placeable
    private var px = 0f; private var py = 0f; private var pw = 0f; private var ph = 0f
    private var cell = 0f
    private val cols = 5
    fun layout(sw: Float, sh: Float) {
        pw = minOf(sw * 0.9f, 700f)
        val rows = (blocks.size + cols - 1) / cols
        cell = pw / cols
        ph = cell * rows + 60f
        px = (sw - pw) / 2f; py = (sh - ph) / 2f
    }
    fun hitBlock(sx: Float, sy: Float): Block? {
        if (!open) return null
        val col = ((sx - px) / cell).toInt()
        val row = ((py + ph - 60f - sy) / cell).toInt()
        if (col < 0 || col >= cols || row < 0) return null
        return blocks.getOrNull(row * cols + col)
    }
    fun hitClose(sx: Float, sy: Float): Boolean =
        open && sx > px + pw - 55 && sx < px + pw - 5 &&
        sy > py + ph - 55 && sy < py + ph - 5
    fun render(shape: ShapeRenderer, sw: Float, sh: Float) {
        if (!open) return
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.color.set(0f, 0f, 0f, 0.6f); shape.rect(0f, 0f, sw, sh)
        shape.color.set(0.14f, 0.14f, 0.18f, 0.98f); shape.rect(px, py, pw, ph)
        for (i in blocks.indices) {
            val r = i / cols; val c = i % cols
            val x = px + c * cell
            val y = py + ph - 60f - (r + 1) * cell
            shape.color.set(0.25f, 0.25f, 0.30f, 1f)
            shape.rect(x + 6, y + 6, cell - 12, cell - 12)
            val b = blocks[i]
            shape.color.set(b.r, b.g, b.b, 1f)
            shape.rect(x + 16, y + 16, cell - 32, cell - 32)
        }
        shape.color.set(0.85f, 0.2f, 0.2f, 1f)
        shape.rect(px + pw - 50, py + ph - 50, 45f, 45f)
        shape.end()
    }
}

object Hud {
    fun draw(shape: ShapeRenderer, player: Player, sw: Float, sh: Float) {
        shape.begin(ShapeRenderer.ShapeType.Filled)
        shape.color.set(0.15f, 0.15f, 0.15f, 0.75f)
        shape.rect(20f, sh - 42f, 240f, 20f)
        shape.color.set(1f, 0.25f, 0.25f, 1f)
        shape.rect(20f, sh - 42f, 240f * (player.hp / 100f), 20f)
        shape.color.set(0.15f, 0.15f, 0.15f, 0.75f)
        shape.rect(20f, sh - 68f, 240f, 16f)
        shape.color.set(0.4f, 0.8f, 1f, 1f)
        shape.rect(20f, sh - 68f, 240f * (player.armor / 100f), 16f)
        shape.color.set(0.15f, 0.15f, 0.15f, 0.75f)
        shape.rect(20f, sh - 94f, 240f, 16f)
        shape.color.set(1f, 0.75f, 0.2f, 1f)
        shape.rect(20f, sh - 94f, 240f * (player.hunger / 100f), 16f)
        shape.end()
    }
    fun drawText(player: Player, sw: Float, sh: Float, fps: Int) {
        TextRender.begin()
        TextRender.text("HP ${player.hp.toInt()}", 270f, sh - 26f)
        TextRender.text("AR ${player.armor.toInt()}", 270f, sh - 54f)
        TextRender.text("FD ${player.hunger.toInt()}", 270f, sh - 80f)
        if (player.flying) TextRender.text("FLY", sw - 120f, sh - 30f, 0.4f, 1f, 1f)
        TextRender.text("FPS $fps", sw - 100f, sh - 55f)
        TextRender.end()
    }
}
